# Bodega Inventory — Native Android App

Pure **native** Android app (Kotlin + Jetpack Compose + Room).  
Hindi WebView.

## Features
- Category grouping, Quantity +/-, 🟢 MERON / 🔴 WALA
- Search, category filter, status filter
- Add / Edit / Delete item
- Backup & Restore JSON, Text export/share
- Offline + persistent (Room database)
- Default 153 items included

---

## Paano kumuha ng APK **nang walang Android Studio** (GitHub Actions)

### 1. Gumawa ng GitHub account
Pumunta sa https://github.com at mag-sign up (libre).

### 2. Gumawa ng bagong repository
- Click **New repository**
- Pangalan: `BodegaInventory` (o kahit ano)
- Public o Private — ok both
- **Huwag** i-check ang "Add README"
- Click **Create repository**

### 3. I-upload ang project
**Option A – sa phone (madali):**
1. I-extract ang zip ng project
2. Buksan ang GitHub app o browser
3. Sa bagong repo, click **uploading an existing file**
4. I-upload **lahat** ng laman ng `BodegaInventory` folder  
   (kasama ang `.github` folder, `app`, `gradle`, `gradlew`, atbp.)
5. Commit

**Option B – kung may computer:**
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/BodegaInventory.git
git push -u origin main
```

### 4. Hintayin ang automatic build
1. Pumunta sa tab na **Actions** sa GitHub repo mo
2. Makikita mo ang workflow na **"Build APK"**
3. Hintayin maging **green** (matagumpay) — usually 3–8 minutes
4. Click ang completed run
5. Sa ilalim, may **Artifacts** → **BodegaInventory-debug**
6. I-download ang zip → extract → makikita mo ang `app-debug.apk`

### 5. I-install sa phone
- I-transfer ang `.apk` sa phone
- Buksan at payagan ang "Install from unknown sources" / "Install unknown apps"
- Install

---

## Manual trigger (ulit na build)
Sa **Actions** tab → **Build APK** → **Run workflow** → Run

---

## Kung may Android Studio
File → Open → piliin ang folder → Build → Build APK(s)

---

Package: `com.bodega.inventory`  
Min SDK: 26 | Target: 35

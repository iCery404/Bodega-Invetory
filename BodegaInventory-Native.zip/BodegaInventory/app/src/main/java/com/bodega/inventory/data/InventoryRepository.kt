package com.bodega.inventory.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class InventoryRepository(context: Context) {
    private val dao = AppDatabase.getDatabase(context).itemDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bodega_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    val items: Flow<List<Item>> = dao.getAllItems()
    val categories: Flow<List<Category>> = dao.getAllCategories()

    suspend fun initializeIfEmpty() {
        val currentItems = dao.getAllItems().first()
        if (currentItems.isEmpty()) {
            dao.insertCategories(DefaultData.categories.map { Category(it) })
            dao.insertItems(DefaultData.items)
            setDate(today())
        }
    }

    fun getDate(): String = prefs.getString("inventory_date", today()) ?: today()

    fun setDate(date: String) {
        prefs.edit().putString("inventory_date", date).apply()
    }

    private fun today(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    suspend fun addItem(name: String, qty: Int, unit: String, category: String) {
        val id = "i" + UUID.randomUUID().toString().take(8)
        dao.insertItem(Item(id, name, qty, unit, category))
    }

    suspend fun updateItem(item: Item) {
        dao.updateItem(item)
    }

    suspend fun deleteItem(item: Item) {
        dao.deleteItem(item)
    }

    suspend fun incrementQty(item: Item) {
        dao.updateItem(item.copy(qty = item.qty + 1))
    }

    suspend fun decrementQty(item: Item) {
        if (item.qty > 0) {
            dao.updateItem(item.copy(qty = item.qty - 1))
        }
    }

    suspend fun addCategory(name: String) {
        dao.insertCategory(Category(name))
    }

    suspend fun resetToDefault() {
        dao.deleteAllItems()
        dao.deleteAllCategories()
        dao.insertCategories(DefaultData.categories.map { Category(it) })
        dao.insertItems(DefaultData.items)
        setDate(today())
    }

    suspend fun exportJson(): String {
        val itemsList = dao.getAllItems().first()
        val cats = dao.getAllCategories().first().map { it.name }
        val payload = mapOf(
            "app" to "bodega-inventory",
            "version" to 1,
            "exportedAt" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()),
            "state" to mapOf(
                "date" to getDate(),
                "categories" to cats,
                "items" to itemsList
            )
        )
        return gson.toJson(payload)
    }

    suspend fun importJson(json: String): Boolean {
        return try {
            val parsed = gson.fromJson(json, Map::class.java)
            val state = parsed["state"] as? Map<*, *> ?: parsed
            val itemsRaw = state["items"] as? List<*> ?: return false
            val catsRaw = state["categories"] as? List<*> ?: DefaultData.categories

            val items = itemsRaw.mapNotNull { raw ->
                val m = raw as? Map<*, *> ?: return@mapNotNull null
                Item(
                    id = m["id"]?.toString() ?: UUID.randomUUID().toString(),
                    name = m["name"]?.toString() ?: "",
                    qty = (m["qty"] as? Double)?.toInt() ?: (m["qty"] as? Int) ?: 0,
                    unit = m["unit"]?.toString() ?: "",
                    category = m["category"]?.toString() ?: "Canned Foods"
                )
            }

            dao.deleteAllItems()
            dao.deleteAllCategories()
            dao.insertCategories(catsRaw.map { Category(it.toString()) })
            dao.insertItems(items)
            setDate(state["date"]?.toString() ?: today())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun buildTextExport(items: List<Item>, categories: List<String>, date: String): String {
        val sb = StringBuilder()
        sb.appendLine("BODEGA INVENTORY")
        sb.appendLine("Petsa: $date")
        sb.appendLine()

        fun section(title: String, predicate: (Item) -> Boolean) {
            sb.appendLine("=== $title ===")
            val groups = categories.mapNotNull { cat ->
                val filtered = items.filter { it.category == cat && predicate(it) }
                    .sortedBy { it.name }
                if (filtered.isEmpty()) null else cat to filtered
            }
            if (groups.isEmpty()) {
                sb.appendLine("(Walang item)")
            } else {
                groups.forEach { (cat, list) ->
                    sb.appendLine()
                    sb.appendLine("[$cat]")
                    list.forEach { item ->
                        val unitStr = if (item.unit.isNotBlank()) " (${item.unit})" else ""
                        sb.appendLine("- ${item.name}$unitStr — ${item.qty}")
                    }
                }
            }
            sb.appendLine()
        }

        section("MERON (May Stock)") { it.qty > 0 }
        section("WALA (Walang Stock)") { it.qty <= 0 }

        val total = items.size
        val inStock = items.count { it.qty > 0 }
        sb.appendLine("----------------------------------------")
        sb.appendLine("Total: $total | Meron: $inStock | Wala: ${total - inStock}")
        return sb.toString()
    }
}

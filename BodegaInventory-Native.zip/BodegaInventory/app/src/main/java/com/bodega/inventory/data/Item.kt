package com.bodega.inventory.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class Item(
    @PrimaryKey val id: String,
    val name: String,
    val qty: Int,
    val unit: String = "",
    val category: String
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val name: String
)

data class InventoryState(
    val date: String = "",
    val items: List<Item> = emptyList(),
    val categories: List<String> = emptyList()
)

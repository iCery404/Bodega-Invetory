package com.bodega.inventory.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF161F19)
val Paper = Color(0xFFF7F3E8)
val PaperCard = Color(0xFFFFFFFF)
val Line = Color(0xFFB9AF95)
val LineStrong = Color(0xFF8C8264)
val Green = Color(0xFF1F5A3E)
val GreenBg = Color(0xFFE4F1E9)
val Red = Color(0xFF9E2E24)
val RedBg = Color(0xFFF7E7E4)
val Amber = Color(0xFFB4790A)
val AmberBg = Color(0xFFFBEBCB)
val AmberBtn = Color(0xFFE3A008)
val Muted = Color(0xFF454B44)

private val LightColors = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    secondary = AmberBtn,
    onSecondary = Color(0xFF241900),
    background = Paper,
    onBackground = Ink,
    surface = PaperCard,
    onSurface = Ink,
    error = Red,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Green,
    onPrimary = Color.White,
    secondary = AmberBtn,
    onSecondary = Color(0xFF241900),
    background = Color(0xFF1A1F1B),
    onBackground = Color(0xFFF3EFE2),
    surface = Color(0xFF242A26),
    onSurface = Color(0xFFF3EFE2),
    error = Red,
    onError = Color.White
)

@Composable
fun BodegaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}

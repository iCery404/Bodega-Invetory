package com.bodega.inventory.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bodega.inventory.data.Item
import com.bodega.inventory.data.InventoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StatusFilter { ALL, IN, OUT }

data class UiState(
    val items: List<Item> = emptyList(),
    val categories: List<String> = emptyList(),
    val date: String = "",
    val searchQuery: String = "",
    val categoryFilter: String = "",
    val statusFilter: StatusFilter = StatusFilter.ALL,
    val totalCount: Int = 0,
    val inCount: Int = 0,
    val outCount: Int = 0,
    val filteredGrouped: Map<String, List<Item>> = emptyMap()
)

class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = InventoryRepository(application)

    private val searchQuery = MutableStateFlow("")
    private val categoryFilter = MutableStateFlow("")
    private val statusFilter = MutableStateFlow(StatusFilter.ALL)
    private val date = MutableStateFlow(repo.getDate())

    private val filters = combine(searchQuery, categoryFilter, statusFilter, date) { q, c, s, d ->
        FilterState(q, c, s, d)
    }

    val uiState: StateFlow<UiState> = combine(
        repo.items,
        repo.categories,
        filters
    ) { items, cats, f ->
        val catNames = cats.map { it.name }
        val filtered = items.filter { item ->
            val matchSearch = f.query.isBlank() || item.name.contains(f.query, ignoreCase = true)
            val matchCat = f.catFilter.isBlank() || item.category == f.catFilter
            val matchStatus = when (f.status) {
                StatusFilter.ALL -> true
                StatusFilter.IN -> item.qty > 0
                StatusFilter.OUT -> item.qty <= 0
            }
            matchSearch && matchCat && matchStatus
        }

        val grouped = catNames
            .filter { f.catFilter.isBlank() || it == f.catFilter }
            .mapNotNull { cat ->
                val list = filtered.filter { it.category == cat }.sortedBy { it.name }
                if (list.isEmpty()) null else cat to list
            }
            .toMap()

        UiState(
            items = items,
            categories = catNames,
            date = f.date,
            searchQuery = f.query,
            categoryFilter = f.catFilter,
            statusFilter = f.status,
            totalCount = items.size,
            inCount = items.count { it.qty > 0 },
            outCount = items.count { it.qty <= 0 },
            filteredGrouped = grouped
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UiState()
    )

    init {
        viewModelScope.launch {
            repo.initializeIfEmpty()
        }
    }

    fun setSearch(query: String) {
        searchQuery.value = query
    }

    fun setCategoryFilter(cat: String) {
        categoryFilter.value = cat
    }

    fun setStatusFilter(filter: StatusFilter) {
        statusFilter.value = filter
    }

    fun setDate(d: String) {
        date.value = d
        repo.setDate(d)
    }

    fun increment(item: Item) {
        viewModelScope.launch { repo.incrementQty(item) }
    }

    fun decrement(item: Item) {
        viewModelScope.launch { repo.decrementQty(item) }
    }

    fun updateItem(item: Item) {
        viewModelScope.launch { repo.updateItem(item) }
    }

    fun deleteItem(item: Item) {
        viewModelScope.launch { repo.deleteItem(item) }
    }

    fun addItem(name: String, qty: Int, unit: String, category: String) {
        viewModelScope.launch { repo.addItem(name, qty, unit, category) }
    }

    fun addCategory(name: String) {
        viewModelScope.launch { repo.addCategory(name) }
    }

    fun resetToDefault() {
        viewModelScope.launch { repo.resetToDefault() }
    }

    suspend fun exportJson(): String = repo.exportJson()

    suspend fun importJson(json: String): Boolean = repo.importJson(json)

    fun buildTextExport(): String {
        val state = uiState.value
        return repo.buildTextExport(state.items, state.categories, state.date)
    }

    private data class FilterState(
        val query: String,
        val catFilter: String,
        val status: StatusFilter,
        val date: String
    )
}

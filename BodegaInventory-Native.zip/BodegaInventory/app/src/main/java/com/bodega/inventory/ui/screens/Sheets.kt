package com.bodega.inventory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bodega.inventory.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemSheet(
    categories: List<String>,
    onDismiss: () -> Unit,
    onAdd: (name: String, qty: Int, unit: String, category: String) -> Unit,
    onAddCategory: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("") }
    var selectedCat by remember { mutableStateOf(categories.firstOrNull() ?: "") }
    var showNewCat by remember { mutableStateOf(false) }
    var newCatName by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Paper,
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "BAGONG ITEM",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    letterSpacing = 0.5.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Isara")
                }
            }

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Pangalan ng Item") },
                placeholder = { Text("hal. Argentina corned beef 150g") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it.filter { c -> c.isDigit() } },
                    label = { Text("Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = unit,
                    onValueChange = { unit = it },
                    label = { Text("Unit (opsyonal)") },
                    placeholder = { Text("hal. tray, box") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            Spacer(Modifier.height(12.dp))

            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = selectedCat,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Kategorya") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = {
                                selectedCat = cat
                                expanded = false
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("+ Bagong Kategorya...") },
                        onClick = {
                            expanded = false
                            showNewCat = true
                        }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    val q = qty.toIntOrNull() ?: 0
                    if (name.isNotBlank() && selectedCat.isNotBlank()) {
                        onAdd(name.trim(), q, unit.trim(), selectedCat)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberBtn, contentColor = Color(0xFF241900)),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("Idagdag", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }

    if (showNewCat) {
        AlertDialog(
            onDismissRequest = { showNewCat = false },
            title = { Text("Bagong Kategorya") },
            text = {
                OutlinedTextField(
                    value = newCatName,
                    onValueChange = { newCatName = it },
                    label = { Text("Pangalan") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newCatName.isNotBlank()) {
                        onAddCategory(newCatName.trim())
                        selectedCat = newCatName.trim()
                        showNewCat = false
                        newCatName = ""
                    }
                }) { Text("Idagdag") }
            },
            dismissButton = {
                TextButton(onClick = { showNewCat = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuSheet(
    searchQuery: String,
    categoryFilter: String,
    categories: List<String>,
    date: String,
    onSearchChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onDateChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onExportText: () -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onReset: () -> Unit
) {
    var showResetConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Paper,
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "MENU",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    letterSpacing = 0.5.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Isara")
                }
            }

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                label = { Text("Maghanap") },
                placeholder = { Text("Maghanap ng item...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )

            Spacer(Modifier.height(12.dp))

            var catExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = it }) {
                OutlinedTextField(
                    value = if (categoryFilter.isEmpty()) "Lahat ng Kategorya" else categoryFilter,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Kategorya") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(catExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                    DropdownMenuItem(
                        text = { Text("Lahat ng Kategorya") },
                        onClick = {
                            onCategoryChange("")
                            catExpanded = false
                        }
                    )
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = {
                                onCategoryChange(cat)
                                catExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = date,
                onValueChange = onDateChange,
                label = { Text("Petsa ng inventory (YYYY-MM-DD)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = onExportText,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberBtn, contentColor = Color(0xFF241900)),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("📄 Gumawa ng Text File", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))

            OutlinedButton(
                onClick = onBackup,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("💾 Mag-backup (.json)", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))

            OutlinedButton(
                onClick = onRestore,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("📥 I-restore mula sa Backup", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))

            OutlinedButton(
                onClick = { showResetConfirm = true },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("I-reset ang Listahan", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Ang backup file ay naglalaman ng buong listahan. Ipasa ang .json kasama ng app.",
                fontSize = 12.sp,
                color = Muted
            )
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("I-reset?") },
            text = { Text("I-reset ang buong inventory pabalik sa orihinal na listahan? Mawawala lahat ng ginawang pagbabago.") },
            confirmButton = {
                TextButton(onClick = {
                    onReset()
                    showResetConfirm = false
                }) { Text("Oo, i-reset", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Hindi") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextExportSheet(
    content: String,
    onDismiss: () -> Unit,
    onShare: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Paper,
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "TEXT FILE",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Isara")
                }
            }

            Text(
                "Ito ang buong listahan sa plain text, hiwalay ang MERON at WALA. Pwede mong i-share diretso sa Messenger/SMS.",
                fontSize = 13.sp,
                color = Muted,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            OutlinedTextField(
                value = content,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 360.dp),
                textStyle = LocalTextStyle.current.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = onShare,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberBtn, contentColor = Color(0xFF241900)),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("📤 I-share / Kopyahin", fontWeight = FontWeight.Bold)
            }
        }
    }
}

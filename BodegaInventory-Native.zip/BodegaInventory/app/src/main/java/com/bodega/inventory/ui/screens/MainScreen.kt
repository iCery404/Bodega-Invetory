package com.bodega.inventory.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bodega.inventory.data.Item
import com.bodega.inventory.ui.components.ItemRow
import com.bodega.inventory.ui.theme.*
import com.bodega.inventory.viewmodel.InventoryViewModel
import com.bodega.inventory.viewmodel.StatusFilter
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: InventoryViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showAddSheet by remember { mutableStateOf(false) }
    var showMenuSheet by remember { mutableStateOf(false) }
    var showTextExport by remember { mutableStateOf(false) }
    var textExportContent by remember { mutableStateOf("") }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            scope.launch {
                try {
                    val input = context.contentResolver.openInputStream(it)
                    val json = BufferedReader(InputStreamReader(input)).readText()
                    val ok = viewModel.importJson(json)
                    snackbarHostState.showSnackbar(
                        if (ok) "Na-restore ang listahan ✓" else "Hindi valid na backup file"
                    )
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Error sa pagbasa ng file")
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Ink)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            "BODEGA INVENTORY",
                            color = Color(0xFFF3EFE2),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            "tally sheet ng stocks",
                            color = Color(0xFFC7D0C6),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        "naka-imbak ✓",
                        color = Color(0xFFA6E2BC),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(Modifier.height(14.dp))

                // Summary chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SummaryChip(uiState.totalCount.toString(), "Total Items", Color(0xFFF3EFE2))
                    SummaryChip(uiState.inCount.toString(), "Meron", Color(0xFF8FD8A9))
                    SummaryChip(uiState.outCount.toString(), "Wala", Color(0xFFF0A090))
                }
            }
        },
        bottomBar = {
            BottomNavBar(
                statusFilter = uiState.statusFilter,
                onStatusChange = { viewModel.setStatusFilter(it) },
                onAddClick = { showAddSheet = true },
                onMenuClick = { showMenuSheet = true }
            )
        },
        containerColor = Paper
    ) { padding ->
        if (uiState.filteredGrouped.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Walang item na tumugma.\nSubukan ibang search, kategorya, o status.",
                    color = Muted,
                    fontSize = 16.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                uiState.filteredGrouped.forEach { (category, items) ->
                    item {
                        CategoryHeader(
                            category = category,
                            inCount = uiState.items.count { it.category == category && it.qty > 0 },
                            totalCount = uiState.items.count { it.category == category }
                        )
                    }
                    items(items, key = { it.id }) { item ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp),
                            color = PaperCard,
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Column {
                                ItemRow(
                                    item = item,
                                    categories = uiState.categories,
                                    onIncrement = { viewModel.increment(item) },
                                    onDecrement = { viewModel.decrement(item) },
                                    onUpdate = { viewModel.updateItem(it) },
                                    onDelete = { viewModel.deleteItem(item) }
                                )
                                HorizontalDivider(color = Line, thickness = 1.dp)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(12.dp)) }
                }
            }
        }
    }

    // Add Item Bottom Sheet
    if (showAddSheet) {
        AddItemSheet(
            categories = uiState.categories,
            onDismiss = { showAddSheet = false },
            onAdd = { name, qty, unit, cat ->
                viewModel.addItem(name, qty, unit, cat)
                showAddSheet = false
            },
            onAddCategory = { viewModel.addCategory(it) }
        )
    }

    // Menu Bottom Sheet
    if (showMenuSheet) {
        MenuSheet(
            searchQuery = uiState.searchQuery,
            categoryFilter = uiState.categoryFilter,
            categories = uiState.categories,
            date = uiState.date,
            onSearchChange = { viewModel.setSearch(it) },
            onCategoryChange = { viewModel.setCategoryFilter(it) },
            onDateChange = { viewModel.setDate(it) },
            onDismiss = { showMenuSheet = false },
            onExportText = {
                textExportContent = viewModel.buildTextExport()
                showTextExport = true
                showMenuSheet = false
            },
            onBackup = {
                scope.launch {
                    val json = viewModel.exportJson()
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_TEXT, json)
                        putExtra(Intent.EXTRA_TITLE, "bodega-inventory-backup.json")
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "I-share ang backup"))
                }
            },
            onRestore = {
                restoreLauncher.launch("application/json")
            },
            onReset = {
                viewModel.resetToDefault()
                showMenuSheet = false
            }
        )
    }

    // Text Export Sheet
    if (showTextExport) {
        TextExportSheet(
            content = textExportContent,
            onDismiss = { showTextExport = false },
            onShare = {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, textExportContent)
                }
                context.startActivity(Intent.createChooser(sendIntent, "I-share ang text"))
            }
        )
    }
}

@Composable
private fun SummaryChip(value: String, label: String, valueColor: Color) {
    Column(
        modifier = Modifier
            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(9.dp))
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(9.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(value, color = valueColor, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(label.uppercase(), color = Color(0xFFC7D0C6), fontSize = 10.sp, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun CategoryHeader(category: String, inCount: Int, totalCount: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .background(Color(0xFFEFE9D6), RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
            .border(2.dp, Line, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
            .padding(14.dp)
    ) {
        Text(
            category.uppercase(),
            color = Green,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            letterSpacing = 0.5.sp
        )
        Text(
            "$inCount / $totalCount meron",
            color = Muted,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun BottomNavBar(
    statusFilter: StatusFilter,
    onStatusChange: (StatusFilter) -> Unit,
    onAddClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    Surface(
        color = PaperCard,
        shadowElevation = 8.dp,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp, top = 4.dp)
                .height(64.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                icon = Icons.Default.List,
                label = "Lahat",
                selected = statusFilter == StatusFilter.ALL,
                selectedColor = AmberBg,
                contentColor = Color(0xFF5A3D05),
                onClick = { onStatusChange(StatusFilter.ALL) },
                modifier = Modifier.weight(1f)
            )
            NavItem(
                icon = Icons.Default.CheckCircle,
                label = "Meron",
                selected = statusFilter == StatusFilter.IN,
                selectedColor = GreenBg,
                contentColor = Green,
                onClick = { onStatusChange(StatusFilter.IN) },
                modifier = Modifier.weight(1f)
            )
            // FAB
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .offset(y = (-12).dp),
                contentAlignment = Alignment.Center
            ) {
                FloatingActionButton(
                    onClick = onAddClick,
                    containerColor = AmberBtn,
                    contentColor = Color(0xFF241900),
                    shape = CircleShape,
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Idagdag", modifier = Modifier.size(28.dp))
                }
            }
            NavItem(
                icon = Icons.Default.Cancel,
                label = "Wala",
                selected = statusFilter == StatusFilter.OUT,
                selectedColor = RedBg,
                contentColor = Red,
                onClick = { onStatusChange(StatusFilter.OUT) },
                modifier = Modifier.weight(1f)
            )
            NavItem(
                icon = Icons.Default.Menu,
                label = "Menu",
                selected = false,
                selectedColor = Color(0xFFEFE9D6),
                contentColor = Ink,
                onClick = onMenuClick,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun NavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    selectedColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) selectedColor else Color.Transparent
    val color = if (selected) contentColor else Muted
    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(bg, RoundedCornerShape(10.dp))
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(28.dp)) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
        }
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

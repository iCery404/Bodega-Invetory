package com.bodega.inventory.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bodega.inventory.data.Item
import com.bodega.inventory.ui.theme.*

@Composable
fun ItemRow(
    item: Item,
    categories: List<String>,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onUpdate: (Item) -> Unit,
    onDelete: () -> Unit
) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var unit by remember(item.id) { mutableStateOf(item.unit) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val isIn = item.qty > 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Name + Unit
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BasicTextField(
                value = name,
                onValueChange = {
                    name = it
                    onUpdate(item.copy(name = it))
                },
                textStyle = TextStyle(
                    fontSize = 16.sp,
                    color = Ink,
                    fontWeight = FontWeight.Medium
                ),
                cursorBrush = SolidColor(Green),
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFFFBF9F2), RoundedCornerShape(8.dp))
                    .border(2.dp, Line, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            )
            BasicTextField(
                value = unit,
                onValueChange = {
                    unit = it
                    onUpdate(item.copy(unit = it))
                },
                textStyle = TextStyle(
                    fontSize = 13.sp,
                    color = Muted,
                    fontFamily = FontFamily.Monospace
                ),
                cursorBrush = SolidColor(Green),
                modifier = Modifier
                    .width(80.dp)
                    .background(Color(0xFFFBF9F2), RoundedCornerShape(8.dp))
                    .border(2.dp, Line, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                decorationBox = { inner ->
                    Box {
                        if (unit.isEmpty()) {
                            Text("unit", color = Muted.copy(alpha = 0.5f), fontSize = 13.sp)
                        }
                        inner()
                    }
                }
            )
        }

        Spacer(Modifier.height(10.dp))

        // Qty controls + stamp
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onDecrement,
                    enabled = item.qty > 0,
                    modifier = Modifier
                        .size(46.dp)
                        .border(2.dp, LineStrong, RoundedCornerShape(9.dp))
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Bawasan", tint = Ink)
                }
                Text(
                    text = item.qty.toString(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.widthIn(min = 40.dp)
                )
                IconButton(
                    onClick = onIncrement,
                    modifier = Modifier
                        .size(46.dp)
                        .border(2.dp, LineStrong, RoundedCornerShape(9.dp))
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Dagdagan", tint = Ink)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isIn) GreenBg else RedBg,
                border = androidx.compose.foundation.BorderStroke(
                    2.dp,
                    if (isIn) Green else Red
                )
            ) {
                Text(
                    text = if (isIn) "🟢 MERON" else "🔴 WALA",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = if (isIn) Green else Red,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Category + Delete
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            var expanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)
                ) {
                    Text(item.category, fontSize = 13.sp, maxLines = 1)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = {
                                onUpdate(item.copy(category = cat))
                                expanded = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = { showDeleteConfirm = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red),
                border = androidx.compose.foundation.BorderStroke(2.dp, Red),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Tanggalin", fontSize = 13.sp)
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Tanggalin?") },
            text = { Text("Tanggalin ang \"${item.name}\"? Hindi na ito mababawi.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete()
                    showDeleteConfirm = false
                }) {
                    Text("Oo, tanggalin", color = Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hindi")
                }
            }
        )
    }
}

// helper to avoid import conflict
private fun Color(hex: Long) = androidx.compose.ui.graphics.Color(hex)

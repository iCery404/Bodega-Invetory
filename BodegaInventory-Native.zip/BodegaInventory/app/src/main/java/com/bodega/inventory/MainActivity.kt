package com.bodega.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bodega.inventory.ui.screens.MainScreen
import com.bodega.inventory.ui.theme.BodegaTheme
import com.bodega.inventory.ui.theme.Paper
import com.bodega.inventory.viewmodel.InventoryViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BodegaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Paper
                ) {
                    val viewModel: InventoryViewModel = viewModel()
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }
}

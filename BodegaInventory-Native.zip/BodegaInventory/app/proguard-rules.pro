# Keep Room and Gson
-keep class com.bodega.inventory.data.** { *; }
